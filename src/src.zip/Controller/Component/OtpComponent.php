<?php

namespace App\Controller\Component;

use Cake\Controller\Component;

class OtpComponent extends Component
{
	public $controller = null;
    public $session = null;

	public function initialize(array $config){
        parent::initialize($config);

        $this->controller = $this->_registry->getController();

        $this->session = $this->controller->request->getSession();

        // You can then use $this->session in any other methods
        // If debug = true else use print_r() to test
        //debug($this->session->read('Auth.User.id'));
    }

    public function sendOtp($phone_no)
	{

		$otp = mt_rand(100000,999999);
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, 'https://api.twilio.com/2010-04-01/Accounts/AC95d67474d7aaed690dc19c2732ee9fa3/Messages.json');
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
			'To' => $phone_no,
			'From' => '+18442637096',
			'Body' => 'Your One Time Password (OTP) Is '.$otp
		]));
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		curl_setopt($ch, CURLOPT_USERPWD, 'AC95d67474d7aaed690dc19c2732ee9fa3:446772a28744eb29a67633cd8524482d');
		$response = curl_exec($ch);
		$status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);

		$this->session->write('otp.no',$otp);
		return $status;
		// $this->session->write('otp.no','123123');
		// return 201;

    }

	public function validate($input){
		$status = 'invalid';
		if($this->session->read('otp.no')==$input){
			$status = 'valid';
		}
		return $status;
	}
}